function [boxes, kind, steps] = find_defects_morph(T, S)

[dy, dx, surface] = phase_correlation(T, S);
shifted = circshift(S, [-dy, -dx]);
before = mean(mean((S < 0.5) ~= (T < 0.5)));
after = mean(mean((shifted < 0.5) ~= (T < 0.5)));
used = after < before;
if used
    S=shifted;
end

BT = T < 0.5;
BS = S < 0.5;
D = double(BS)-double(BT);
SE=ones(5);
nearCopper = imdilate(BT,SE);
deepCopper = imerode(BT, SE);
extra = D > 0 & ~nearCopper;
missing = D < 0 & deepCopper;
[M,N] = size(T);
boxes = zeros(0, 4);
kind=zeros(0, 1);
masks = {extra,missing};
for m = 1:2
    [L, n]=bwlabel(masks{m}, 8);
    for k=1:n
        [r, c] = find(L == k);
        x1 = min(c); x2 = max(c); y1 = min(r); y2 = max(r);
        if numel(r) < 10, continue; end
        if x2-x1 < 2||y2-y1<2, continue; end
        if x1 <= 6 || y1 <= 6 || x2 > N - 6 || y2 > M - 6, continue; end
        boxes(end + 1, :) = [x1 y1 x2 y2];
        kind(end+1, 1) = m;
    end
end

steps.BT = BT;
steps.nearCopper = nearCopper;
steps.deepCopper=deepCopper;
steps.D = D;
steps.extra=extra;
steps.missing=missing;
end
