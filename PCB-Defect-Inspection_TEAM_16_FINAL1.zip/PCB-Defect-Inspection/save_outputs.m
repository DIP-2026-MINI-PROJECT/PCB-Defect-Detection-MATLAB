clear; close all; clc;
ids={'20085291', '12100000', '44000011', '90100000', '50600050', ...
       '00041200', '12000001', '12300060', '13000198', '77000100', '92000111'};
out = fullfile(fileparts(mfilename('fullpath')), 'outputs');
if ~exist(out, 'dir'), mkdir(out); end

fprintf('%-10s %9s %7s %14s\n', 'board', 'labelled', 'found', 'false alarms');
for i = 1:numel(ids)
    [T, S, labels]=read_board(ids{i});
    [boxes, kind]=find_defects(T, S);
    [found, falseAlarms] = check_result(boxes, kind, labels);
    fprintf('%-10s %9d %7d %14d\n', ids{i}, numel(found),sum(found),falseAlarms);

    fig=figure('Visible', 'off', 'Position',[100 100 700 720]);
    imshow(S); hold on;
    for k = 1:size(labels, 1)
        L = labels(k,:);
        rectangle('Position', [L(1), L(2),L(3) - L(1),L(4)-L(2)], 'EdgeColor', 'g', 'LineWidth',1);
    end
    colours = {'r', 'b'};
    for k = 1:size(boxes,1)
        b = boxes(k, :);
        rectangle('Position', [b(1)-4,b(2)-4,b(3)-b(1) + 8, b(4) - b(2)+8], ...
                  'EdgeColor', colours{kind(k)}, 'LineWidth',2);
    end
    hold off;
    title(sprintf('%s: %d of %d found, %d false alarms',ids{i},sum(found),numel(found), falseAlarms));
    saveas(fig, fullfile(out, [ids{i} '_result.png']));
    close(fig);
end
fprintf('Saved %d result pictures in %s\n', numel(ids), out);