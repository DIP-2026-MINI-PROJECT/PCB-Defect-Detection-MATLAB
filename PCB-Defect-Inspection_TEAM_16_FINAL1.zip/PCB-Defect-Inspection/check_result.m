function [found, falseAlarms] = check_result(boxes, kind, labels)
wantKind=1+ismember(labels(:, 5), [1 3 6]);
found = false(size(labels, 1), 1);
matched = false(size(boxes,1),1);

for i=1:size(boxes,1)
    for j = 1:size(labels,1)
        b = boxes(i, :);
        g = labels(j,1:4);
        overlap = b(1)<=g(3) && g(1)<=b(3) && b(2) <= g(4) && g(2)<=b(4);
        if overlap && kind(i) == wantKind(j)
            found(j) = true;
            matched(i)=true;
        end
    end
end
falseAlarms = sum(~matched);
end
