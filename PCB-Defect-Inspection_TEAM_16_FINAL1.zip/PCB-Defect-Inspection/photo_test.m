clear; close all; clc;
folder = fullfile(fileparts(mfilename('fullpath')), 'data', 'photos');
faultyName = 'faulty1.jpg';

photoG = load_photo(fullfile(folder, 'good.jpg'));
photoF = load_photo(fullfile(folder,faultyName));
PG=find_corners(photoG);
PF = find_corners(photoF);
[G, F,boxes, changed, shift]=inspect_photos(photoG, photoF,PG, PF);
fprintf('%s: slide fixed by phase correlation = (%d, %d) px, changes found = %d\n',...
        faultyName,shift(1),shift(2),size(boxes,1));

figure('Name', 'Photo test', 'Position',[40 80 1600 520]);
subplot(1, 3,1); imshow(G); title({'good board', '(straightened)'});
subplot(1, 3, 2); imshow(F); title({faultyName, sprintf('%d changes found', size(boxes, 1))});
hold on;
for i=1:size(boxes, 1)
    b = boxes(i, :);
    rectangle('Position', [b(1)-3, b(2)-3, b(3)-b(1) + 6, b(4)-b(2)+6], ...
              'EdgeColor', 'r', 'LineWidth', 2);
end
hold off;
subplot(1, 3, 3); imshow(changed); title({'what changed', '(after the 3 px tolerance, opening, closing)'});
saveas(gcf, 'photo_test.png');