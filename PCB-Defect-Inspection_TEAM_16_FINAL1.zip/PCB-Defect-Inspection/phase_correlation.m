function [dy, dx, surface] = phase_correlation(A, B)
[M, N] = size(A);
FA = fft2(A);
FB = fft2(B);
R = FB .* conj(FA);
R = R ./ (abs(R) + eps);
surface = real(ifft2(R));
[~,idx]=max(surface(:));
[p, q] = ind2sub([M N], idx);
dy = p - 1;
dx=q-1;

if dy > M / 2, dy = dy - M; end
if dx > N / 2, dx = dx - N; end
end
