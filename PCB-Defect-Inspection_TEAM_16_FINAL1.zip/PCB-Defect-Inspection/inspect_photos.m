function [G, F, boxes, changed, shift] = inspect_photos(photoG, photoF, PG, PF)

W=800;
threshold=0.2;
minArea=30;

if size(photoG,3) == 1,photoG = repmat(photoG, [1 1 3]); end
if size(photoF,3)==1,photoF=repmat(photoF,[1 1 3]); end
if ~isequal(size(photoF), size(photoG))
    photoF=imresize(photoF, [size(photoG, 1) size(photoG, 2)]);
end
if nargin < 4, PF = PG; end
PG = order_corners(PG); PF=order_corners(PF);
boardW = (norm(PG(2,:) - PG(1,:)) + norm(PG(3,:) - PG(4, :))) / 2;
boardH = (norm(PG(4, :) - PG(1, :)) + norm(PG(3, :) - PG(2, :))) / 2;
H = round(W * boardH / boardW);
corners = [1 1; W 1; W H; 1 H];
G = warp4(photoG, corners, PG, W, H);
F = warp4(photoF, corners,PF, W,H);
flipped = rot90(F, 2);
if mean(abs(flipped(:) - G(:))) < mean(abs(F(:) - G(:)))
    F = flipped;
end

[dy, dx] = phase_correlation(rgb2gray(G), rgb2gray(F));
shifted=circshift(F, [-dy, -dx]);
shift=[0 0];
if mean(abs(shifted(:) - G(:))) < mean(abs(F(:) - G(:)))
    F = shifted;
    shift = [dx dy];
end

for ch = 1:3
    F(:,:,ch)=F(:, :, ch)*mean(mean(G(:, :,ch))) / mean(mean(F(:,:, ch)));
end

blur = fspecial('gaussian', 7, 1.5);
G = imfilter(G,blur, 'replicate');
F = imfilter(F, blur, 'replicate');

D = inf(H, W);
for sy = -3:3
    for sx = -3:3
        Gs = circshift(G, [sy,sx]);
        D = min(D, sqrt(sum((F - Gs) .^ 2,3)));
    end
end
changed = D > threshold;

changed = imopen(changed, ones(3));
changed=imclose(changed,ones(7));

[L, n]=bwlabel(changed, 8);
boxes = zeros(0, 4);
for k=1:n
    [r, c] = find(L == k);
    x1 = min(c); x2 = max(c); y1 = min(r); y2 = max(r);
    if numel(r) < minArea,continue; end
    if x2 - x1 < 5 || y2 - y1 < 5, continue; end
    if x1 <= 0.02 * W || y1 <= 0.02 * H || x2 > 0.98 * W || y2 > 0.98 * H,continue; end
    boxes(end + 1, :)=[x1 y1 x2 y2];
end
end

function P = order_corners(P)
s = P(:, 1) + P(:, 2); d = P(:, 1) - P(:, 2);
[~, a]=min(s); [~,b]=max(d); [~,c] = max(s); [~, e]=min(d);
P = P([a b c e],:);
end