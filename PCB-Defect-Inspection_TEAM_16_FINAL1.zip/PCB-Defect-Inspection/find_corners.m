function P = find_corners(img)
gray = rgb2gray(img);
board = gray < 0.5 * median(gray(:));
board=imfill(board, 'holes');
board=imopen(board,ones(15));
[L, n]=bwlabel(board, 8);
sizes=zeros(n,1);
for k = 1:n
    sizes(k) = nnz(L == k);
end
[~, biggest]=max(sizes);
[r, c]=find(L==biggest);
s = c + r; d = c - r;
[~,i1] = min(s); [~, i2] = max(d); [~,i3] = max(s); [~,i4] = min(d);
P=[c(i1) r(i1); c(i2) r(i2); c(i3) r(i3); c(i4) r(i4)];
end