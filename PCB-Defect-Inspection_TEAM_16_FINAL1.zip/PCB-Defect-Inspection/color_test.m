clear; close all; clc;
ids={'20085291', '12100000', '44000011', '90100000', '50600050',...
       '00041200', '12000001', '12300060', '13000198', '77000100', '92000111'};
copperRGB=[0.80 0.45 0.20];
boardRGB = [0.15 0.75 0.25];
modes={'grayscale (rgb2gray)', 'hue (HSV colour model)', ...
         'hue, with colour noise', 'hue, colour noise + smoothing'};
fprintf('%-32s %9s %13s\n', 'how the colour photo is read', 'found/66', 'false alarms');
for m = 1:numel(modes)
    rng(1);
    found = 0; falseAlarms = 0;
    for i = 1:numel(ids)
        [T, S, labels]=read_board(ids{i});
        CT = zeros([size(T) 3]); CS = zeros([size(S) 3]);
        for ch = 1:3
            CT(:, :, ch) = T * boardRGB(ch) + (1 - T) * copperRGB(ch);
            CS(:,:,ch)=S*boardRGB(ch)+(1-S)*copperRGB(ch);
        end
        if m >= 3
            CS = min(max(CS + 0.1 * randn(size(CS)), 0), 1);
        end
        if m == 4
            CS = imfilter(CS,fspecial('average', 5), 'replicate');
        end
        if m == 1
            T2=rgb2gray(CT);
            S2 = rgb2gray(CS);
        else
            hT = rgb2hsv(CT); hS = rgb2hsv(CS);
            T2 = double(hT(:, :, 1) > 0.22);
            S2 = double(hS(:,:, 1) > 0.22);
        end
        [boxes, kind]=find_defects(T2, S2);
        [f,fa] = check_result(boxes,kind,labels);
        found=found + sum(f);
        falseAlarms=falseAlarms+fa;
    end
    fprintf('%-32s %9d %13d\n',modes{m},found,falseAlarms);
end

[T, S] = read_board('20085291');
CS = zeros([size(S) 3]);
for ch = 1:3
    CS(:, :, ch) = S * boardRGB(ch) + (1 - S) * copperRGB(ch);
end
hsvS = rgb2hsv(CS);
figure('Name', 'Colour', 'Position',[40 80 1500 480]);
subplot(1, 3, 1); imshow(CS); title({'colour "photo"', 'copper = orange, board = green'});
subplot(1, 3, 2); imshow(rgb2gray(CS)); title({'grayscale: copper 0.526, board 0.514', 'almost the same - detector finds 0'});
subplot(1, 3, 3); imshow(hsvS(:, :, 1), []); title({'hue: copper 0.07, board 0.36', 'clearly different - detector works'});
saveas(gcf, 'color_test.png');
