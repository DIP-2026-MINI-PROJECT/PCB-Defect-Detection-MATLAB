function [T, S] = clean_image(T, S, fix)

switch fix
    case 'none'

    case 'average 5x5'
        S = imfilter(S, fspecial('average', 5), 'replicate');
    case 'median 3x3'
        S = medfilt2(S, [3 3]);

    case 'median 5x5'
        S=medfilt2(S,[5 5]);
    case 'histogram equalization'
        S=histeq(S);

    case 'contrast stretching'
        S = (S - min(S(:))) / (max(S(:)) - min(S(:)));

    case 'sharpen'
        blur = fspecial('gaussian', 9,2);
        T = T + 3 * (T - imfilter(T,blur, 'replicate'));
        S=S+3*(S - imfilter(S, blur, 'replicate'));

    case 'low-pass lighting'
        illum=gauss_lowpass(S,5)./gauss_lowpass(T,5);
        S = S ./ illum;

    case 'notch filter'
        S = notch_filter(T, S);

    case 'open-close 2x2'
        BT=T>0.5; BS = S>0.5;
        BT = imclose(imopen(BT, ones(2)), ones(2));
        BS = imclose(imopen(BS,ones(2)),ones(2));
        T = double(BT); S = double(BS);
end
end

function out = gauss_lowpass(I, D0)
[M, N] = size(I);
[u, v] = meshgrid(1:N, 1:M);
D=sqrt((u - floor(N/2)-1) .^ 2 + (v - floor(M/2)-1).^2);
H=exp(-D.^2/(2*D0 ^ 2));
out = real(ifft2(ifftshift(fftshift(fft2(I)) .* H)));
end

function S = notch_filter(T, S)
[M,N] = size(S);
FS=fftshift(fft2(S));
FT = fftshift(fft2(T));
extra = abs(FS) - abs(FT);
[u,v] = meshgrid(1:N,1:M);
c=[floor(M / 2)+1, floor(N/2)+1];
extra(sqrt((u-c(2)) .^ 2 + (v - c(1)) .^ 2)<10) = 0;
[~, k]=max(extra(:));
[py,px] = ind2sub([M N],k);
qy = 2 * c(1) - py; qx = 2 * c(2) - px;
H = ones(M, N);
H(sqrt((u - px) .^ 2 + (v - py) .^ 2) <= 3) = 0;
H(sqrt((u-qx).^2+(v - qy) .^ 2)<=3)=0;
S = real(ifft2(ifftshift(FS .* H)));
end
