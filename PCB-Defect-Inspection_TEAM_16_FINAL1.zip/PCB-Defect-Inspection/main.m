clear; close all; clc;
ids = {'20085291', '12100000', '44000011', '90100000', '50600050',...
       '00041200', '12000001', '12300060', '13000198', '77000100', '92000111'};
totals = [0 0 0];
fprintf('%-10s %9s %7s %14s\n', 'board', 'labelled', 'found', 'false alarms');
for i=1:numel(ids)
    [T, S, labels] = read_board(ids{i});
    [boxes, kind] = find_defects(T, S);
    [found,falseAlarms]=check_result(boxes,kind,labels);
    fprintf('%-10s %9d %7d %14d\n', ids{i}, numel(found), sum(found),falseAlarms);
    totals = totals + [numel(found), sum(found), falseAlarms];
end
fprintf('%-10s %9d %7d %14d\n', 'total', totals);

id='20085291';
[T,S,labels]=read_board(id);
[boxes,kind, steps] = find_defects(T,S);
[found, falseAlarms] = check_result(boxes, kind, labels);
if steps.used
    verdict = 'used';
else
    verdict = 'not used, it does not help';
end
fprintf('\nBoard %s: the DFT says the test scan is shifted by dy = %d, dx = %d px (%s)\n',...
        id, steps.shift(1), steps.shift(2), verdict);
fprintf('Found %d of %d labelled defects, %d false alarms\n',sum(found), numel(found), falseAlarms);
figure('Name',['Board ' id], 'Position',[50 50 1500 900]);
cmap = [1 1 1; 0.75 0.75 0.75; 1 0 0; 0 0 1];

subplot(2, 3, 1); imshow(T); title('1. Template (defect-free)');
subplot(2, 3, 2); imshow(S); title('2. Test board');

subplot(2, 3, 3);
C = fftshift(steps.surface);
imagesc(-15:15, -15:15,C(306:336,306:336)); axis image; colorbar;
xlabel('dx (px)'); ylabel('dy (px)');
title({'3. DFT phase correlation',sprintf('spike at dy = %d, dx = %d (%s)', steps.shift(1), steps.shift(2), verdict)});

subplot(2, 3, 4);
V = 1 + double(steps.BT); V(steps.D>0) = 3; V(steps.D<0)=4;
imshow(ind2rgb(V, cmap));
title({'4. test - template, after alignment', 'red = +1 extra, blue = -1 missing'});

subplot(2,3, 5);
V = 1 + double(steps.BT); V(steps.extra) = 3; V(steps.missing) = 4;
imshow(ind2rgb(V, cmap));
title({'5. ignore differences within 2 px', 'of a template edge (D8 distance)'});

subplot(2,3,6); imshow(S); hold on;
names={'open', 'short', 'mousebite', 'spur', 'copper', 'pin-hole'};
for j = 1:size(labels, 1)
    g = labels(j, :);
    rectangle('Position',[g(1),g(2), g(3) - g(1),g(4)-g(2)], 'EdgeColor', 'g');
    text(g(1), g(2) - 10, names{g(5)}, 'Color', 'g', 'FontSize', 8);
end
for i = 1:size(boxes, 1)
    b = boxes(i, :);
    if kind(i) == 1, col = 'r'; else, col='b'; end
    rectangle('Position', [b(1) - 4, b(2) - 4, b(3) - b(1) + 8, b(4) - b(2) + 8], 'EdgeColor', col, 'LineWidth',2);
end
hold off;
title({sprintf('6. Result: %d of %d found, %d false alarms', sum(found), numel(found), falseAlarms), ...
       'red / blue = ours, green = label'});
saveas(gcf, 'result.png');
