clear; close all; clc;
ids = {'20085291', '12100000', '44000011', '90100000', '50600050', ...
       '00041200', '12000001', '12300060', '13000198', '77000100', '92000111'};

fprintf('%-10s %16s %16s %14s %14s\n', 'board', 'grow: differ px', 'shrink: differ px', 'phase 1 found', 'morph found');
total1 = 0; total2 = 0;
for i = 1:numel(ids)
    [T, S, labels] = read_board(ids{i});
    BT=T<0.5;
    grow1 = bwdist(BT, 'chessboard') <= 2;
    grow2 = imdilate(BT, ones(5));
    shrink1 = bwdist(~BT, 'chessboard') > 2;
    shrink2=imerode(BT, ones(5));
    [b1, k1]=find_defects(T, S);
    [b2,k2] = find_defects_morph(T,S);
    f1 = check_result(b1, k1, labels);
    f2 = check_result(b2, k2, labels);
    fprintf('%-10s %16d %16d %14d %14d\n', ids{i},nnz(grow1 ~= grow2),nnz(shrink1 ~= shrink2),sum(f1), sum(f2));
    total1=total1+sum(f1); total2=total2+sum(f2);
end
fprintf('%-10s %16s %16s %14d %14d\n', 'total', '', '', total1, total2);

[T, S] = read_board('20085291');
[~, ~, steps] = find_defects_morph(T, S);
rr = 150:330; cc = 180:310;
cmap=[1 1 1; 0.75 0.75 0.75; 1 0 0; 0 0 1];
figure('Name', 'Morphology', 'Position',[40 80 1600 560]);
subplot(1, 4, 1); imshow(~steps.BT(rr, cc));
title({'1. template copper (black)', 'the structuring element is a 5 x 5 square'});

subplot(1, 4, 2); imshow(~steps.nearCopper(rr, cc));
title({'2. dilation: copper grown by 2 px', 'extra copper must be OUTSIDE this'});

subplot(1,4,3); imshow(~steps.deepCopper(rr,cc));
title({'3. erosion: copper shrunk by 2 px', 'missing copper must be INSIDE this'});
V = 1 + double(steps.BT); V(steps.extra) = 3; V(steps.missing) = 4;
subplot(1, 4, 4); imshow(ind2rgb(V(rr, cc), cmap));
title({'4. what is left: real defects only', 'red = extra, blue = missing'});
saveas(gcf, 'morphology_demo.png');
