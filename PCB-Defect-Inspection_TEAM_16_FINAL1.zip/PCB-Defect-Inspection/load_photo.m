function [img, P] = load_photo(file)

img = im2double(imread(file));
s = 1600 / max(size(img, 1), size(img, 2));
if s<1
    img = imresize(img, s);
end

if nargout > 1
    [d, name]=fileparts(file);
    cornerFile = fullfile(d, [name '_corners.txt']);
    if exist(cornerFile, 'file')
        P = load(cornerFile);
    else
        figure; imshow(img);
        title('click the 4 board corners: top-left, top-right, bottom-right, bottom-left');
        [x,y] = ginput(4);
        P=[x y];
        close;
        save(cornerFile, 'P', '-ascii');
    end
end
end
