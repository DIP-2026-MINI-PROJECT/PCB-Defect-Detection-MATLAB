function out = warp4(img, Q, P, W, H)

A=zeros(8); r=zeros(8, 1);
for i=1:4
    u = Q(i, 1); v = Q(i, 2); x = P(i, 1); y = P(i, 2);
    A(2*i - 1, :) = [u v 1 0 0 0 -u*x -v*x]; r(2*i - 1) = x;
    A(2*i, :) = [0 0 0 u v 1 -u*y -v*y]; r(2*i) = y;
end
p = A \ r;

[U, V] = meshgrid(1:W, 1:H);
den = p(7) * U + p(8) * V + 1;
X = (p(1) * U + p(2) * V + p(3)) ./ den;
Y = (p(4) * U + p(5) * V + p(6)) ./ den;
out = zeros(H, W, size(img, 3));
for ch=1:size(img, 3)
    out(:, :, ch)=interp2(img(:, :, ch), X, Y, 'linear', 0);
end
end