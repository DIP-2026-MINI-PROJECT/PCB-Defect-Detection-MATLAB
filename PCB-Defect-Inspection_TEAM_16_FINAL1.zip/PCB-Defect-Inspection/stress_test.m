clear; close all; clc;
tests = {
   'none',0, 'none'
   'low resolution',2, 'none'
   'low resolution', 4, 'none'
   'low resolution', 6, 'none'
   'low resolution', 8, 'none'
   'low resolution', 4, 'sharpen'
   'gaussian noise', 0.3, 'none'
   'gaussian noise',0.3, 'average 5x5'
   'gaussian noise', 0.3, 'median 5x5'
   'salt & pepper',0.05, 'none'
   'salt & pepper', 0.05, 'median 3x3'
   'salt & pepper', 0.05, 'open-close 2x2'
   'salt & pepper',0.2, 'none'
   'salt & pepper', 0.2, 'median 3x3'
   'salt & pepper',0.2, 'open-close 2x2'
   'dim light', 0.4, 'none'
   'dim light', 0.4, 'histogram equalization'
   'dim light',0.4, 'contrast stretching'
   'uneven light', 0.3, 'none'
   'uneven light',0.3, 'low-pass lighting'
   'stripes',0.6, 'none'
   'stripes',0.6, 'notch filter'
   'blur', 3, 'none'
   'blur', 3, 'sharpen'
};
ids = {'20085291', '12100000', '44000011', '90100000', '50600050', ...
       '00041200', '12000001', '12300060', '13000198', '77000100', '92000111'};
fprintf('%-16s %6s   %-24s %9s %13s\n', 'damage', 'amount', 'fix', 'found/66', 'false alarms');
for t=1:size(tests,1)
    rng(1);
    found = 0; falseAlarms = 0;
    for i = 1:numel(ids)
        [T,S,labels] = read_board(ids{i});
        [T, S]=damage_image(T, S, tests{t, 1}, tests{t, 2});
        [T, S]=clean_image(T, S, tests{t, 3});
        [boxes, kind] = find_defects(T, S);
        [f, fa]=check_result(boxes,kind,labels);
        found=found+sum(f);
        falseAlarms = falseAlarms + fa;
    end
    fprintf('%-16s %6g   %-24s %9d %13d\n', tests{t, 1},tests{t,2},tests{t,3}, found,falseAlarms);
end

show = {
   'low resolution', 4, 'sharpen'
   'gaussian noise', 0.3, 'median 5x5'
   'salt & pepper', 0.2, 'median 3x3'
   'dim light', 0.4, 'contrast stretching'
   'uneven light', 0.3, 'low-pass lighting'
   'stripes',0.6, 'notch filter'
   'blur', 3, 'sharpen'
};
rr=40:420; cc=120:480;
[T0, S0, labels] = read_board('20085291');
n = size(show, 1);
figure('Name', 'Stress test', 'Position',[30 60 1700 600]);
for k = 1:n
    rng(1);
    [T,S]=damage_image(T0,S0,show{k,1},show{k, 2});
    [boxes, kind] = find_defects(T, S);
    [f,fa]=check_result(boxes,kind,labels);
    subplot(2, n, k); imshow(S(rr, cc));
    title({show{k,1},sprintf('%d of 9 found, %d false',sum(f),fa)});

    [T, S] = clean_image(T, S, show{k, 3});
    [boxes, kind]=find_defects(T, S);
    [f, fa] = check_result(boxes,kind,labels);
    subplot(2, n, n + k); imshow(S(rr, cc));
    title({['+ ' show{k,3}],sprintf('%d of 9 found, %d false', sum(f), fa)});
end
saveas(gcf, 'stress_test.png');
