function [T, S] = damage_image(T, S, damage, amount)

[M, N] = size(S);
switch damage
    case 'none'

    case 'low resolution'
        T = imresize(imresize(T, 1/amount, 'bilinear'),[M N], 'bilinear');
        S = imresize(imresize(S,1 / amount, 'bilinear'), [M N], 'bilinear');
    case 'gaussian noise'
        S=S + amount*randn(M, N);

    case 'salt & pepper'
        S = imnoise(S, 'salt & pepper', amount);

    case 'dim light'
        S=amount*S;

    case 'uneven light'
        illum = repmat(linspace(1, amount, N), M, 1);
        S=S .* illum;
    case 'stripes'
        stripes = repmat(sin(2 * pi * (1:N) / 8),M, 1);
        S=S + amount*stripes;

    case 'blur'
        S=imfilter(S,fspecial('gaussian',6*amount + 1, amount), 'replicate');
end
end
