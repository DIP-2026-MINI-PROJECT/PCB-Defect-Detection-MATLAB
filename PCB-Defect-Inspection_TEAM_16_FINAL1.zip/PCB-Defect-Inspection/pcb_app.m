function pcb_app

phoneWords = {'DroidCam', 'Iriun', 'Phone', 'Virtual', 'Camo'};

app.folder = fullfile(fileparts(mfilename('fullpath')), 'data', 'photos');
if ~exist(app.folder, 'dir'), mkdir(app.folder); end
outDir = fullfile(fileparts(mfilename('fullpath')), 'outputs');
if ~exist(outDir, 'dir'), mkdir(outDir); end
app.cam = [];
app.camText = 'no phone camera: buttons 1 and 2 load photo files';
try
    names=webcamlist;
    for i = 1:numel(names)
        if any(cellfun(@(w) ~isempty(strfind(lower(names{i}), lower(w))), phoneWords))
            app.cam=webcam(names{i});
            app.camText=['camera: ' names{i}];
            break;
        end
    end
catch
end
app.photoG=[]; app.photoF=[]; app.PG=[]; app.PF=[]; app.k=0;

dark=[0.06 0.09 0.08]; light=[0.93 0.95 0.92]; copper = [0.88 0.54 0.24];
app.fig=figure('Name', 'PCB inspection', 'NumberTitle', 'off', 'MenuBar', 'none', ...
                 'ToolBar', 'none', 'Color', dark, 'Position', [60 60 1400 760]);
app.axG=axes('Parent', app.fig, 'Position', [0.03 0.25 0.45 0.66], 'Visible', 'off');
app.axF = axes('Parent', app.fig, 'Position',[0.52 0.25 0.45 0.66], 'Visible', 'off');
app.status = uicontrol(app.fig, 'Style', 'text', 'Units', 'normalized',...
    'Position',[0.03 0.03 0.94 0.06], 'FontSize', 18, 'BackgroundColor', dark,...
    'ForegroundColor', light, 'String',['Press 1. Good board   (' app.camText ')']);
labels={'1. Good board', '2. Faulty board', '3. Inspect', 'Saved photos', 'Corners'};
actions = {@on_good, @on_faulty,@on_inspect,@on_saved,@on_corners};
for i=1:5
    colour = copper;
    if i>3, colour = [0.55 0.61 0.58]; end
    uicontrol(app.fig, 'Style', 'pushbutton', 'String',labels{i}, 'FontSize',18, ...
        'FontWeight', 'bold', 'BackgroundColor', colour, 'ForegroundColor', dark, ...
        'Units', 'normalized', 'Position', [0.03+(i-1)*0.19, 0.12,0.17, 0.08],...
        'Callback', actions{i});
end
guidata(app.fig, app);
end
function on_good(src, ~)
app = guidata(src);
img = get_photo(app, 'good');
if isempty(img), return; end
imwrite(img, fullfile(app.folder, 'last_good.jpg'));
app.photoG=img;
app.PG = find_corners(img);
show(app.axG, img, 'good board',app.PG);
set(app.status, 'String', 'Press 2. Faulty board');
guidata(src, app);
end

function on_faulty(src, ~)
app = guidata(src);
img=get_photo(app, 'faulty');
if isempty(img),return; end
imwrite(img, fullfile(app.folder, 'last_faulty.jpg'));
app.photoF=img;
app.PF = find_corners(img);
show(app.axF,img, 'faulty board',app.PF);
set(app.status, 'String', 'Press 3. Inspect');
guidata(src, app);
end

function on_saved(src, ~)
app = guidata(src);
for step = 1:9
    k = mod(app.k + step - 1, 9) + 1;
    if exist(fullfile(app.folder, sprintf('faulty%d.jpg', k)), 'file'), break; end
end
faultyFile = fullfile(app.folder, sprintf('faulty%d.jpg', k));
if ~exist(fullfile(app.folder, 'good.jpg'), 'file') || ~exist(faultyFile, 'file')
    set(app.status, 'String', 'Put good.jpg and faulty1.jpg in the photos folder first');
    return;
end
app.photoG=load_photo(fullfile(app.folder, 'good.jpg'));
app.photoF = load_photo(faultyFile);
app.PG=find_corners(app.photoG);
app.PF = find_corners(app.photoF);
app.k = k;
show(app.axG, app.photoG, 'good.jpg',app.PG);
show(app.axF, app.photoF, sprintf('faulty%d.jpg',k), app.PF);
set(app.status, 'String', 'Press 3. Inspect');
guidata(src, app);
end

function on_corners(src, ~)
app = guidata(src);
if isempty(app.photoG)
    set(app.status, 'String', 'Take or load the good board photo first');
    return;
end
show(app.axG, app.photoG, 'click the 4 board corners',[]);
set(app.status, 'String', 'Click the 4 board corners on the good photo');
axes(app.axG);
[x, y] = ginput(4);
app.PG = [x y];
app.PF = [x y];
show(app.axG, app.photoG, 'good board (corners clicked)', app.PG);
set(app.status, 'String', 'Corners set. Press 3. Inspect');
guidata(src,app);
end

function on_inspect(src, ~)
app = guidata(src);
if isempty(app.photoG)||isempty(app.photoF)
    set(app.status, 'String', 'Take both photos first');
    return;
end
set(app.status, 'String', 'Inspecting ...');
drawnow;
[G, F,boxes] = inspect_photos(app.photoG,app.photoF,app.PG, app.PF);
show(app.axG, G, 'good board (straightened)', []);
show(app.axF, F, sprintf('%d changes found',size(boxes,1)),[]);
hold(app.axF, 'on');
for i = 1:size(boxes, 1)
    b=boxes(i, :);
    rectangle('Parent',app.axF, 'Position', [b(1)-4, b(2)-4, b(3)-b(1)+8, b(4)-b(2) + 8], ...
              'EdgeColor',[1 0.25 0.25], 'LineWidth',3);
end
hold(app.axF, 'off');
set(app.status, 'String', sprintf('%d changes found', size(boxes, 1)));
frame = getframe(app.fig);
imwrite(frame.cdata, fullfile(fileparts(mfilename('fullpath')), 'outputs', 'app_result.png'));
end
function img = get_photo(app, name)
img = [];
if ~isempty(app.cam)
    for i=1:5
        img = snapshot(app.cam);
    end
    img = im2double(img);
else
    [f, p] = uigetfile({'*.jpg;*.jpeg;*.png', 'Photos'}, ['Choose the ' name ' board photo'], app.folder);
    if ~isequal(f, 0)
        img = load_photo(fullfile(p, f));
    end
end
end

function show(ax, img, txt, P)
imshow(img, 'Parent', ax);
title(ax,txt, 'Color', [0.93 0.95 0.92], 'FontSize', 16);
if ~isempty(P)
    hold(ax, 'on');
    plot(ax,[P(:,1); P(1,1)],[P(:,2); P(1,2)], 'c-', 'LineWidth', 2);
    hold(ax, 'off');
end
end