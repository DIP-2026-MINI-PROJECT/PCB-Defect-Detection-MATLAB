function [T, S, labels] = read_board(id)

folder = fullfile(fileparts(mfilename('fullpath')), 'data');
T = imread(fullfile(folder, [id '_temp.jpg']));
S = imread(fullfile(folder, [id '_test.jpg']));
if size(T,3) == 3,T = rgb2gray(T); end
if size(S, 3) == 3, S = rgb2gray(S); end

T=im2double(T);
S = im2double(S);
labels = load(fullfile(folder,[id '.txt']));
labels(:,1:4)=labels(:,1:4) + 1;
end
